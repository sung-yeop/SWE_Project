package com.SWEProject.BackEnd.addOn;

import lombok.Data;

@Data
public class moveRequest {
    private String path;
}
