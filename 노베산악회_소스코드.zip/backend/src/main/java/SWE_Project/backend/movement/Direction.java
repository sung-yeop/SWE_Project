package SWE_Project.backend.movement;

public enum Direction {
    UP, DOWN, LEFT, RIGHT;
}
