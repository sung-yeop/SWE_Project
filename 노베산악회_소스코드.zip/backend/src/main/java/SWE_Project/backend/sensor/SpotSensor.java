package SWE_Project.backend.sensor;

public class SpotSensor {



}
