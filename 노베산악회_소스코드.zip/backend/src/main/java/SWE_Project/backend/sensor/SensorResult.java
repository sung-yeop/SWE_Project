package SWE_Project.backend.sensor;

public enum SensorResult {
    HAZARD, SPOT, SAFE;
}
